﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class procStats
    {
        private int p;
        private int s;
        private int b;

        public int getp() {
            return p;

        }

        public void setp(int a) {
            p = a;
            
        }

        public int gets() {
            return s;
        }

        public void sets(int a)
        {
            s = a;

        }

        public int getb() {
            return b;
        }

        public void setb(int a)
        {
            b = a;

        }





    }
    
}
